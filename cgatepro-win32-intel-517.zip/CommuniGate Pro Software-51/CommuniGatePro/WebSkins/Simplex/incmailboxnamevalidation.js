// A set of rules to check the name of a new Mailbox being created, before being submitted to the CGP server.

function ValidateMailboxName(mbxName){
	
	if (!ValidateMailboxName1(mbxName.value)){
		mbxName.value = "";
		return false;
		}
	return true;
	}
	
function ValidateMailboxName1(mbxName){

	// Verify that the Mailbox name does not start with an illegal character
	if ((mbxName.charAt(0) == '\\') | (mbxName.charAt(0) == '\/')){window.alert("Mailbox name starts with an illegal character");
	return false;}

	var mbxLen = mbxName.length - 1;
	// Verify that the Mailbox name does not end with an illegal character
	if ((mbxName.charAt(mbxLen) == '\\') | (mbxName.charAt(mbxLen) == '\/')){window.alert("Mailbox name end with an illegal character");
	return false;}

	return true;
	}
