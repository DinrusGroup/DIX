//
// This page is to configure the toolbar on the Composer settings page
//

config = new HTMLArea.Config();
config.toolbar = [
[
'fontname','space',
'fontsize','space',
'formatblock','space',
'bold','italic','underline'],
[
'justifyleft','justifycenter','justifyright','justifyfull','separator',
'orderedlist','unorderedlist','outdent','indent','separator',
'forecolor','separator',
'inserthorizontalrule','createlink','htmlmode','separator',
'cut','copy','paste']
];
config.pageStyle =
  'body { background: #FFFFFF; font-family: Arial,Helvetica,sans-serif; font-size: 12px; color: #000000; } ';