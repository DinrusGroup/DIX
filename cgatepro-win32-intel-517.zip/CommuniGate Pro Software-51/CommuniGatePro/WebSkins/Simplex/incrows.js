
// A script to highligh rows when selected
function CCA(CB){
ie = 0;
if (CB.checked)
hL(CB);
else
dL(CB);

function hL(E){
if (ie)
{
while (E.tagName!="TR")
{
E=E.parentElement;
}
}
else{
while (E.tagName!="TR")
{
E=E.parentNode;
}
}
E.className = "H";
}

function dL(E){
if (ie)
{
while (E.tagName!="TR")
{
E=E.parentElement;
}
}
else{
while (E.tagName!="TR")
{
E=E.parentNode;
}
}
E.className = "";
}

}

function CCB(CB){
ie = 0;
hL(CB);

function hL(E){
if (ie)
{
while (E.tagName!="TR")
{
E=E.parentElement;
}
}
else{
while (E.tagName!="TR")
{
E=E.parentNode;
}
}
E.className = "O";
}

}

function CCC(CB){
ie = 0;
if (CB.checked)
hL(CB);
else
dL(CB);

function hL(E){
if (ie)
{
while (E.tagName!="TR")
{
E=E.parentElement;
}
}
else{
while (E.tagName!="TR")
{
E=E.parentNode;
}
}
E.className = "H";
}

function dL(E){
if (ie)
{
while (E.tagName!="TR")
{
E=E.parentElement;
}
}
else{
while (E.tagName!="TR")
{
E=E.parentNode;
}
}
E.className = "";
}

}
