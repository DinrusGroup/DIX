function testDoc(oDoc){

   if(!oDoc.forms[0]){
      setTimeout(testDoc(oDoc), 1000); 
   }
}
function setSortParameter(box,sort,desc,obj){
    if(desc==0) desc = 1;
    else desc=0;
    var params = new Array();
    
    var uri = document.location.href;
    uri = (uri.split("?"))[0];
    lof =  uri.lastIndexOf("/");
    uri =  uri.substring(0,lof);

    var requestURI = uri+"/settings.wssp";
    //alert(requestURI);

    ifr = document.getElementById("formRemember");
    sendPostRequest(requestURI, 
                function(data) {
                 var oIframe = ifr;
                 var oDoc = (oIframe.contentWindow || oIframe.contentDocument);
                 if (oDoc.document) {
          	    oDoc = oDoc.document;
                 }
                 oDoc.open("text/html");
                 oDoc.write(data);
                 oDoc.close();
                    setTimeout(function() { 
                         testDoc(oDoc);
                         var fld = oDoc.forms[0].doImageSubmit;
                         fld.name = "Update";
                         fld.value = 1;
                         pp = oDoc.getElementsByName("SortColumn");
                         for(i=0; i<pp.length; i++){
                                  if(pp[i].value == sort){ pp[i].checked = true; }
                         }
                         /*
                         for(i in pp){
                              alert(pp[i]+":"+pp[i].type);
                              if(pp[i].type=="radio"){
                                  if(pp[i].value== sort) pp[i].checked = true;
                                  else pp[i].checked = false;
                              }
                         }
                         */
                         sort = oDoc.getElementsByName("DescSort")[0];
                         opt =  sort.options;
                         for(i=0; i<opt.length; i++){
                                  if(opt[i].value == desc) sort.selectedIndex = i;
                         }
                         sendForm(requestURI, oDoc.forms[0], 
                                    function(form,data){
                                       if(obj && obj.href) document.location.href=obj.href;
                                    });
                      },1000);
             }
     ,null);
};
