// A script to paste multiple addresses from the LDAP search window back to the Compose page
// then remove the addresses from the found list
var singleSelect = true;  //Only allow a located name to be used once. IE, don't Cc and Bcc at same time.

function itemSelect (theField) {
var address_object = theField;
var BookList = document.LDAP.Book;
var BookIndex = BookList.selectedIndex;

while (BookIndex > -1) {
	if (window.opener.document.Compose[address_object].value == ''){
		window.opener.document.Compose[address_object].value = BookList.options[BookIndex].text;
	}
	else {
		window.opener.document.Compose[address_object].value=window.opener.document.Compose[address_object].value + ', ' + BookList.options[BookIndex].text;
	}

	// Remove the selected item from the list
	if (singleSelect) {
		BookList.options[BookIndex] = null;
	}
	BookIndex = BookList.selectedIndex;
}
// Close the function
}
