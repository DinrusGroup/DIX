<!--
function linkTimer(){
timeOn = setTimeout("HideComposeOptions()",12000)
}
function HideComposeOptions(){
MM_showHideLayers('ComposeOptions','','hide')
MM_showHideLayers('ComposeOptions2','','hide')
}
//-->
