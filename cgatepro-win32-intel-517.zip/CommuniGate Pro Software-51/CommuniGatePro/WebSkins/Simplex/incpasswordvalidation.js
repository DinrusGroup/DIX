// A set of rules to compare the two new Passwords being entered by the user
// before being submitted to the CGP server.
//
//  Comment or Uncomment those parts of the rules you do or don't want to apply to the users.
//
// Courtesy of nicolas.hatier@niversoft.com

function ValidatePassword(pw1, pw2, theLogonName){

	userName = theLogonName;
	
	if (!ValidatePassword1(pw1.value, pw2.value)){
		pw1.value = "";
		pw2.value = "";
		return false;
		}
	return true;
	}
	
function ValidatePassword1(pw1, pw2){

	// Verify that password does not contain the account name
	if (pw1.toLowerCase().indexOf(userName.toLowerCase()) >= 0){window.alert("Password must not contain the account name '" + userName +  "'");return false;}

	// Verify that the two new passwords match
	if (pw1 != pw2){window.alert(userName + ", The new Passwords don't match!");
	return false;}

	// Verify that the new password is greater than 6 characters	
	if (pw1.length < 6){window.alert( userName + ", Passwords must be six characters or more");
	return false;}

	// Verify that the password contains at least one number
	// if (pw1.search(/[0-9]/) < 0){window.alert("Passwords must contains at least one number");
	// return false;}

	// Verify that the password contains at least one letter	
	// if (pw1.search(/[a-zA-Z]/) < 0){window.alert("Passwords must contains at least one letter");
	// return false;}

	return true;
	}
