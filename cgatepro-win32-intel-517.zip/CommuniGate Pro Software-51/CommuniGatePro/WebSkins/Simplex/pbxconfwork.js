
  function File(name, data, MIME) {
    this.name = name;
    this.data = data;
    this.MIME = MIME==null?"text/plain":MIME;
    
  }
  File.prototype.getType= function() { return "file"; }
  File.prototype.getFileName= function() { return this.name; }
  File.prototype.getFileData= function() { return this.data; }
  File.prototype.getFileMIME= function() { return this.MIME; }

    function sendFile() {
        copyFormToObject(); 
        document.form.result.value=CGPData.stringify(obj);

        createFolder("website.wssp", createFolderDone);
    }

    
    function createFolder(URI, readyFunc) {
        var createFolderData = {"FormCharset":"utf-8", 
                                "RenameName":"",
                                "NewName":"private",
                                "CreateDir":"1",
                                "SubDir":""
                               };
        sendPostRequest(URI, readyFunc, createFolderData);
    }
    function createFolderDone(data) {
        createSubFolder("website.wssp?SubDir=private", createSubFolderDone);
    }

    function createSubFolder(URI, readyFunc) {
        var createSubFolderData = {"FormCharset":"utf-8", 
                                "RenameName":"",
                                "NewName":"settings",
                                "CreateDir":"1",
                                "SubDir":"private"
                               };
        sendPostRequest(URI, readyFunc, createSubFolderData);
    }

    function createSubFolderDone(data) {
        var f = new File("name.txt", CGPData.stringify(obj));
        createFile("website.wssp?SubDir=private/settings", f, createFileDone);
    }
    function createFile(URI, file, readyFunc) { 
        var createFileData = {"FormCharset":"utf-8", 
                              "RenameName":"",
                              "NewName":"",
                              "Create":"1",
                              "Upload":file,
                              "SubDir":"private/settings"
                             };
        sendPostRequest(URI, readyFunc, createFileData);
    }
    function createFileDone(data) {
        alert("Done")
    }

    var obj = {"ifbusy": {"action": "default", "target": "default"},
                "afterRinging": {"timeout": 10, "action": "default", "target": "default"},
                "blacklist": []}; 
