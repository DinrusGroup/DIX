var mykey;
var myconvertedkey;

if (window.Event){
	document.captureEvents(Event.KEYDOWN);
	}
document.onkeydown = myKeyDown;
function myKeyDown(e){
if (window.Event){
	mykey = e.which;
	}
else{
	mykey = event.keyCode
	}

myconvertedkey = String.fromCharCode(mykey);

if (mykey == "6"){
	window.open('helpmail.wssp','Help','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=300,left=20,top=20');
	}
}