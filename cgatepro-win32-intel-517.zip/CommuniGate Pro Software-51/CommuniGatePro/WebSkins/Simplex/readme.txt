Configuring Simplex's preferences via the strings.data file.
-------------------------------------------------------------------

The strings.data file not only contains the words and phrases used in the construction of the skin, it also contains a number of preference settings that allow the skin's administrator to alter the behaviour.

This document serves to outline the purpose of these preferences and their effect. All preferences are shown with their default setting.

prefLoginLogoutDelay = "3";
- When a user first logs into webmail, there is a short delay before their INBOX is automatically opened into the Main frame area. Changing this preference's numeric value will alter this delay period, measured in seconds. It also alters the subsequent delay period the user experiences when they log off, prior to being automatically returned to the login page. If this value is set to "0" , then the user is not presented with the dialogue that they've logged in / off successfully, they are redirected straight into their INBOX.

prefPreloadImages  = "No";
- All icons and graphic items inside the skin are referred to by their correct path so that, if setup correctly, a web browser can cache the items, thereby allowing the pages to load faster (even between sessions). However, if the connection speed to the CGP server hosting webmail is quite high and the administrator wants to maximise the skin's performance, all the graphics can be pre-loaded into the browser's cache during the delay period before the user's INBOX is opened (set with prefLoginLogoutDelay).

prefMailboxesFrameWidth = "215";
- The skin uses a single frame called 'Mailboxes' to hold the tree structure that represents all the user's mailboxes. The user can resize the Mailboxes frame by dragging its edge in their web browser. Changing this preference's numeric value, measured in pixels, alters the default width of the Mailboxes frame, so as to accommodate very long mailbox names.

prefMailboxesTreeIcons = "Yes"; 
- Each mailbox in the list of Mailboxes has its own icon. Each of the default mailboxes also has a unique icon. You can reduce the time taken to load all these icons in the tree by turning off the display of the mailbox icons. Changing this preference to "No" will cause the Mailboxes tree to be constructed with no icons (name of Mailbox only). 

prefMailboxesTreeSubdivided = "Yes";
- The Mailboxes frame displays all the user's mailboxes in two distinct sets. The first is those default mailboxes that have been designated to act as the repository for all incoming, outgoing, deleted or draft messages, plus any default calendar, event, note or contact mailboxes that have been defined in the Settings. The next set the user sees are the custom mailboxes they have created for the storage or sorting of their items. Changing this preference to "No" will make the skin present to the user all mailboxes in one, contiguous set (with no distinction between the user's personal mailboxes and those defined as defaults) plus reduce the time taken to create the mailbox tree structure.

prefJunkMailboxName = "Junk";
- An administrator of CGP might have in place a set of rules or applications that scans incoming messages to identify Spam, and then have those messages placed inside a specific mailbox for the user to browse. This setting allows that mailbox to be identified with a unique icon and placed in the set of default mailboxes (see above) for easy identification, or for matching with a similar Junk mailbox mechanism in some IMAP applications.

prefNewMailAlert = "No";
- By default, the user is given no notification when a new message arrives in their INBOX. If this preference is set to "Yes", then a small JavaScript dialogue box is opened and a sound played whenever a new, recent message arrives in a user's INBOX.

prefTextNavigationButtons = "No";
- By default, all the small buttons for navigating the webmail pages are icon based (using small *.gif files for their content). Changing this preference to "Yes" will make the content of the button a text word and the graphic file not downloaded. This makes the skin load faster and the function of the button more obvious.

prefComposeTextHeight = "280";
- The Compose page has a text box into which the user types the body of their message. Changing this preference's numeric value, measured in pixels, controls the height of this text box, so as to fine tune the amount of space available for the user to type into before the text box presents scroll bars.

prefComposeTextWidthFixed = "Yes";
- The Compose page has a text box into which the user types the body of their message. Normally, the skin sets the width of this text box as being 100%, so as to always provide the maximum width available for the user to type their message. However, CGP contains a setting to allow the admin and user to define how many Columns wide their message should be restricted to. Changing this preference to "No" will allow CGP's Column setting to take effect and also reveal the option to set this value on the Settings / Composing page.

NB. When using the Text Toolbar Extra, the width of the text box on the Compose page is always set to 100% and the option to alter the Column width is removed from the Settings / Compose page. Therefore, prefComposeTextWidthFixed has no effect.

prefComposeAttachments = "5";
- The Compose page has an Attachments button that, when clicked, produces a floating popup that allows the user to select files to attach to their message. Altering this value allows the administrator to specify how many such files can be attached to a message. If set to zero ("0"), the Attachments button is hidden and the popup not included on the Compose page.

prefComposeLDAPSearchingAllowed = "Yes";
- The Compose page has a button that provides the user with a floating window that allows them to search the entire CGP server's LDAP database looking for email addresses. The ability to locate all addresses in all domains might provide too much information, or reveal names that are not meant to be publicly available. Setting this preference to "No" will hide the LDAP Search button on the Compose page and render the associated window ineffective.

prefComposeReturnsToINBOX = "Yes";
- A message can be composed in a number of ways. If the message composition request originated from a mailbox or message, webmail will return the user to that mailbox once the message has been sent or saved. If there is no originating mailbox or message, the webmail will return to the INBOX. Changing this preference to "No" will make completed message composition, that did not originate from a mailbox or other message, return to the blank.wssp page in the �Main� frame area.

prefMessageReplyReturnsToMailbox = "No";
- When a user replies to a message, the webmail will attempt to return them the originating message once the composed reply message has been sent (see above). Changing this preference will skip returning them to the message and will take them back to the originating mailbox. This can save time when replying to multiple messages or the behaviour of other maill apps needs to be emulated.

prefPasswordValidation = "Yes";
- The Settings / Password page allows a user, if the matching option is enabled by the CGP administrator, to alter their password. The webmail uses a small bit of JavaScript to check some basic criteria regarding the creation of new passwords. These �rules� are defined in the file 'incpasswordvalidation.js'. The default Password Validation rules are:

1. The password does not contain the account name
2. The 'new password' and 'confirm password' fields match
3. The password is greater than 6 characters
4. The password contains at least one number
5. The password contains at least one letter

Should any of these criteria not be met, the user is presented with an alert box, advising them of their mistake. Setting this preference to "No" will prevent any of the above rules being applied to new password creation. If you can read JavaScript, you can alter the incpasswordvalidation.js file to remove or alter any of the Password Validation rules

prefRulesVisible = "Yes";
- Even though CGP provides the administrator with the ability to stop the user from altering or creating message handling Automated Rules, disabling access to Rules also stops the user from being able to set a Vacation Message or Mail Redirection. Setting this preference to "No" will hide the rules on the Rules page whilst the Automated Rules option is active for that user, thereby allowing them to still set Vacation Messages or Mail Redirection.

prefFromAddressChangeable = "Yes";
- The webmail user normally has the ability to alter their From address, via the Settings / Compose page. Changing this preference to "No" will show their From address as a non-alterable text field and hide the corresponging [Change] hyperlink on the Compose page.

prefSettingsGeneralEnabled = "Yes";
prefSettingsComposeEnabled = "Yes";
prefSettingsContactsEnabled = "Yes";
- The Settings / General, Compose and Contacts pages in the webmail contain large numbers of options that a CGP administrator cannot stop a user from altering. Alteration of these options can lead to erratic skin behaviour and subsequent user confusion as to the operation of the options. Changing this preference to "No" will hide all 'dangerous' options from those pages and allow them to only be altered by the admin, using CGP's defaults

prefPersonalWebsiteAvailable = "Yes";
- Each webmail user can be allocated a Personal Website, which becomes available when the CGP admin activates the WebSite option and also allocates that the user is allowed to have more than 0 Kb of space to store files. However, the functionality of the WebCal is also dependant of there being more than 0 Kb of space available to store the freebusy.vfb file. So, in effect, enabling WebCal and allowing storage space effectively negates the state of the WebSite option. Changing this preference to "No" will override the state of the WebCal, WebSite and storage space options and hide the Personal Website button in the Navigation frame, plus make the website page ineffective. This allows WebCal to be in operation, storage space available, but no Personal Website access provided for the user.
