//
// This page is to configure the toolbar on the Compose page
//

var config = new HTMLArea.Config(); // create new config object
config.toolbar = [
[
'fontname','space',
'fontsize','space',
'formatblock','space',
'bold','italic','underline','separator',
'strikethrough','subscript','superscript'],
[
'justifyleft','justifycenter','justifyright','justifyfull','separator',
'orderedlist','unorderedlist','outdent','indent','separator',
'forecolor','separator',
'inserthorizontalrule','createlink','insertimage','htmlmode','separator',
'cut','copy','paste']
];
config.pageStyle =
  'body { background: #FFFFFF; font-family: Arial,Helvetica,sans-serif; font-size: 12px; color: #000000; } ';