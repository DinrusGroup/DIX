// A simple script to updates the contents of the Navigation frame
function refreshNavigation() {
var theSessionID = "";
theSessionID = String(arguments[0]);
parent.frames[0].document.location = "/Session/" + theSessionID + "/navigate.wssp";
}

// refreshMailboxes
// A simple script to updates the contents of the Mailboxes frame, if it is visible
function refreshMailboxes() {
var newCount = GetCookie('mailboxesVisible');
if(newCount == 1) {
	top.frames[0].document.location = 'mailboxes.wssp'
	}
}

// Reads from a cookie, if required
function GetCookie(name)
{  
	var arg = name + "=";  
	var alen = arg.length;  
	var clen = document.cookie.length;  
	var i = 0;  

	while (i < clen) {    
		var j = i + alen;    
		if (document.cookie.substring(i, j) == arg)      
			return getCookieVal (j);    
		i = document.cookie.indexOf(" ", i) + 1;    
		if (i == 0) break;   
	}  
	return null;
}

function getCookieVal(offset) {  
	var endstr = document.cookie.indexOf (";", offset);  
	if (endstr == -1)    
	endstr = document.cookie.length;  
	return unescape(document.cookie.substring(offset, endstr));
}
