// A simple script to mark / unmark all check boxes on the page
var checkflag = "false";
function check(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;
CCA(field[i]);
}
checkflag = "true";
return "Unmark all";
}
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false;
CCA(field[i]);
}
checkflag = "false";
return "Mark all";
}
}
