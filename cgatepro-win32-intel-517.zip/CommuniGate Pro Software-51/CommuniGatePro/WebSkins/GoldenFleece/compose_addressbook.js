/* ------------------------------------------------- */
var i = 0;

elemAddrBook = new Array();
elemIdAddrBook = new Array();

function addressBookAdd(param,i)
{
	str1 = document.forms[0].elements['selectedAddressBook'].options[document.forms[0].elements['selectedAddressBook'].selectedIndex].value ;

	if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[1].name = 'selectedAddressBook';
	if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[1].value = str1;

	var indxHidden = 2;
	for (k=0; k<i; k++)
	{
		if(document.forms[0].elements['Book'].options[k].selected)
			if (indxHidden < 12) 
			{
				str = document.forms[0].elements['Book'].options[k].value ; 
				if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[indxHidden].name = 'Book';
				if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[indxHidden].value = str;
				indxHidden++;
			}
			else break ;
	}

	switch (param) 
	{
		case 'To':	
			if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[12].name = 'ToBook';
			if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[12].value = 'To';
			break;
		case 'Cc':	
			if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[12].name = 'CcBook';
			if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[12].value = 'To';
			break;
		case 'Bcc':	
			if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[12].name = 'BccBook';
			if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].elements[12].value = 'To';
			break;
		default:
			 break
	}

	if(parent && parent.rightFrame0) parent.rightFrame0.document.forms[0].submit();

	return;
}

function addressBookDisplay()
{
	document.forms[0].elements[1].name = 'OpenBook';
	document.forms[0].elements[1].value = 'Display';

	document.forms[0].action = 'compose.wssp?addressBook=1&MessageText=00&';
	document.forms[0].submit();
	
	return;
}

function addressBookDelete()
{
	document.forms[0].elements[1].name = 'DeleteBook';
	document.forms[0].elements[1].value = 'Delete';

	document.forms[0].action = 'compose.wssp?addressBook=1&MessageText=00&';
	document.forms[0].submit();
	
	return;
}
function addressBookAddNew()
{
	document.forms[0].elements[1].name = 'AddBook';
	document.forms[0].elements[1].value = 'Add New';

	document.forms[0].action = 'compose.wssp?addressBook=1&MessageText=00&';
	document.forms[0].submit();
	
	return;
}

/* ---------------------------------------------- --- */
