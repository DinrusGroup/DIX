function bar_tree3(colBoxes, Draftsbox, Sentbox, Trashbox, ListLinkTag, detectDir) {
	doc = doc + '<table cellpadding=2 cellspacing=0 border=0 width="100%">'
	doc = doc + '<tr valign=top height="100%">'
	doc = doc + '	<td><img src="1blank.gif" width="10"></td>'
	doc = doc + '	<td width="100%">'
	doc = doc + '<table cellpadding=2 cellspacing=0 border=0 width="100%">'
	doc = doc + '<tr valign=top>'
	doc = doc + '	<td width="25%" id="tree1">'
	
	var flag = 0;
	var numList = -1;
	
	for (var i = 0; i < colBoxes; i++) {
		checkTilda = treeBoxes[i].indexOf('~');
		if (checkTilda > -1) {
			arrayOfStrings = treeBoxes[i].split('/');
			arrayOfStrings[arrayOfStrings.length - 1] = treeBoxes[i];
		} else 
			arrayOfStrings = treeBoxes[i].split('/');
	
		doc = doc + '<div class=treeItem id="leaf' + i + '">';
		doc = doc + '  <div class=treeItemCaption>';
		doc = doc + '    <div class=tree_menu><img src="leaf.gif" width=9 height=9 border=0 align=center>';
		if (treeBoxes[i] == treeBoxesINDX) 		doc = doc + '    <img src="folderinbox.gif" width=21 height=16 border=0>';
		else if (treeBoxes[i] == Draftsbox) 	doc = doc + '    <img src="folderdrafts.gif" width=21 height=16 border=0>';
		else if (treeBoxesNotes[i] == 1) 		doc = doc + '    <img src="foldernotes.gif" width=21 height=16 border=0>';
		else if (treeBoxesCalendar[i] == 1) 	doc = doc + '    <img src="folderappoint.gif" width=21 height=16 border=0>';
		else if (treeBoxesTasks[i] == 1) 		doc = doc + '    <img src="foldertasks.gif" width=21 height=16 border=0>';
		else if (treeBoxesContacts[i] == 1) 	doc = doc + '    <img src="foldercontact.gif" width=21 height=16 border=0>';
		else if (treeBoxes[i] == Sentbox) 		doc = doc + '    <img src="folderoutbox.gif" width=21 height=16 border=0>';
		else if (treeBoxes[i] == Trashbox) 		doc = doc + '    <img src="foldertrash.gif" width=21 height=16 border=0>';
		else if (treeBoxesSelectable[i] == 0)	doc = doc + '    <img src="folderlight.gif" width=21 height=16 border=0>';
		else if (checkTilda > -1) 				doc = doc + '    <img src="foldersub.gif" width=21 height=16 border=0>';
		else									doc = doc + '    <img src="folder.gif" width=21 height=16 border=0>';
		
		if (treeBoxesCalendar[i] == 1 || treeBoxesTasks[i] == 1) 
			doc = doc + '    <a href="' + treeBoxesURL[i] + '" onclick="reloadHeader(1);"  target=rightFrame1 class=treeItemLink>' + arrayOfStrings[arrayOfStrings.length-1] + '</a></div>';
		else if (treeBoxesSelectable[i] == 0)
			doc = doc + '<font color="#666666">' + arrayOfStrings[arrayOfStrings.length-1] + '</font></div>';
		else if (treeBoxesList[i] == 1) {
			numList = numList + 1;
			parent.parent.sizeBox[i] = treesizeBox[i]; 
			parent.parent.messageBox[i] = treemessageBox[i];
			parent.parent.recentBox[i] = treerecentBox[i];
			parent.parent.unreadBox[i] = treeunreadBox[i];
			doc = doc + '    <a href="' + treeBoxesURL[i] + '" onclick="reloadHeader(0); reloadrightFrame();" target=rightFrame1 class=treeItemLink>' + arrayOfStrings[arrayOfStrings.length-1] + '</a>&nbsp;&nbsp;<a href="ListSettings.wssp" onclick="goLIST(' + numList + ')"><TT>' + ListLinkTag + '</TT></a></div>';
		} else {
			parent.parent.sizeBox[i] = treesizeBox[i]; 
			parent.parent.messageBox[i] = treemessageBox[i];
			parent.parent.recentBox[i] = treerecentBox[i];
			parent.parent.unreadBox[i] = treeunreadBox[i];
			if (detectDir == "RTL") {
				if (treeunreadBox[i] != 0) 
					doc = doc + '&nbsp;&nbsp;<span id="div_0' + i + '">(<b><font color="#FF0000">' + top.unreadBox[i] + '</font></b>]</span>';
				else 
					doc = doc + '&nbsp;&nbsp;<span id="div_0' + i + '">&nbsp;</span>';
				doc = doc + '&nbsp;&nbsp;<font color="#666666"><span id="div_1' + treeBoxesId[i] + '">' + top.sizeBox[i] + '&nbsp;-&nbsp;' + top.messageBox[i] +  '</span></font>';
				doc = doc + '    <a href="' + treeBoxesURL[i] + '" onclick="reloadHeader(0); reloadrightFrame(); defIdMSGTmp();" target=rightFrame1 class=treeItemLink>' + arrayOfStrings[arrayOfStrings.length-1] + '</a></div>';
			} else {
				if (treeBoxes[i] == treeBoxesINDX) doc += '    <b>';
				doc = doc + '    <a href="' + treeBoxesURL[i] + '" onclick="reloadHeader(0); reloadrightFrame(); defIdMSGTmp();" target=rightFrame1 class=treeItemLink>' + arrayOfStrings[arrayOfStrings.length-1] + '</a>';
				if (treeBoxes[i] == treeBoxesINDX) doc += '</b>';
				doc = doc + '&nbsp;&nbsp;<font color="#666666"><span id="div_1' + treeBoxesId[i] + '">' + top.sizeBox[i] + '&nbsp;-&nbsp;' + top.messageBox[i] +  '</span></font>';
				if (treeunreadBox[i] != 0) 
					doc = doc + '&nbsp;&nbsp;<span id="div_0' + i + '">(<b><font color="#FF0000">' + top.unreadBox[i] + '</font></b>]</span></div>';
				else 
					doc = doc + '&nbsp;&nbsp;<span id="div_0' + i + '">&nbsp;</span></div>';
			}
		}
		doc = doc + '  </div>';
	
		if (i == colBoxes - 1) {
			for (var j=0; j<=flag; j++) {
				doc = doc + '</div>';
			}
			doc = doc + '</td></td></tr></table>';
			return doc;
		}

		arrayOfStrings1 = treeBoxes[i].split('/');
		arrayOfStrings2 = treeBoxes[i+1].split('/');
		checkTilda = treeBoxes[i+1].indexOf('~');
		if (checkTilda > -1) {
			for (var k=0; k<=arrayOfStrings1.length-1; k++) {
				doc = doc  + '</div>';
			}
			flag = flag - arrayOfStrings1.length-1;
			continue;
		}
		if (arrayOfStrings1.length < arrayOfStrings2.length) {
			flag++;
			continue;
		}
		if (arrayOfStrings1.length == arrayOfStrings2.length) {
			doc = doc  + '</div>';
			continue;
		}
		if (arrayOfStrings1.length > arrayOfStrings2.length) {
			for (var k=0; k<=arrayOfStrings1.length-arrayOfStrings2.length; k++) {
				doc = doc  + '</div>';
			}
			flag = flag - arrayOfStrings1.length-arrayOfStrings2.length;
			continue;
		}
	
	}
	doc = doc + '</td></td></tr>'
	doc = doc + '</table>';
	return doc;
}
