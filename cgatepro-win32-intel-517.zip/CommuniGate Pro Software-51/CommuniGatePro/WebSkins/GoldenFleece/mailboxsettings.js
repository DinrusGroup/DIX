	function funReset()
	{
		document.forms[0].elements[1].name = 'Reset';
		document.forms[0].submit();
		return;
	}

	function funUpdate()
	{
		document.forms[0].elements[1].name = 'Update';
		document.forms[0].submit();
		return;
	}

	function funRemove()
	{
		document.forms[0].elements[1].name = 'Remove';
		document.forms[0].submit();
		return;
	}

	function funRename()
	{
		document.forms[0].elements[1].name = 'Rename';
		document.forms[0].submit();
		return;
	}

	function funDeleteAll()
	{
		document.forms[0].elements[1].name = 'DeleteAll';
		document.forms[0].submit();
		return;
	}

