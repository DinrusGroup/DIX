function menuMailbox(param)
{
	if (param == 'MarkAll')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='MarkAll';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';
		return true;
	}

	if (param == 'Read')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='Read';
		parent.rightFrame1.document.forms[0].elements[1].value='Set';
		return true;
	}
	if (param == 'UnRead')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='UnRead';
		parent.rightFrame1.document.forms[0].elements[1].value='Clear';
		return true;
	}

	if (param == 'Flag')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='Flag';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';
		return true;
	}
	if (param == 'UnFlag')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='UnFlag';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';
		return true;
	}

	if (param == 'Delete')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='Delete';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';
		return true;
	}
	if (param == 'UnDelete')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='UnDelete';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';
		return true;
	}
	if (param == 'Purge')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='Purge';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';
		return true;
	}
	

	if (param == 'Management')
	{
		str = 'mailboxsettings.wssp?Mailbox=';
		str += parent.parent.boxName;
		str += '&';

		checkReSize('550','300');

		parent.rightFrame2.document.location = str;
		parent.rightFrame3.document.location = 'blank4.html';

		return true;
	}
}
//-----------------------------------------------------------------------------
