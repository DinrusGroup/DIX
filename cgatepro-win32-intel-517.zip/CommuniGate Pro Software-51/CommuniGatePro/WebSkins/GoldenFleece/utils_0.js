function checkReSize(param1,param2)
{ 
	param1 = '27\,' + param1 + '\,*,27';
	param2 = '27\,' + param2 + '\,*,27';
	isIE = (document.all ? true : false);
	isDOM = (document.getElementById ? true : false);

	if (parent.parent.sizeFrame == param1)
	{
		if (isIE) if(parent && parent.rightFrame) parent.rightFrame.rows=param2;
		else {
                     if(parent && parent.document && parent.document.getElementById('rightFrame') )  parent.document.getElementById('rightFrame').rows=param2;
                }
	}
	else
	{
		if (isIE) if(parent && parent.rightFrame) parent.rightFrame.rows=parent.parent.sizeFrame;
		else{
		   if(parent && parent.document && parent.document.getElementById('rightFrame')) parent.document.getElementById('rightFrame').rows=parent.parent.sizeFrame 
		}
	}

}

function ReSize(param)
{ 
	param1 = '27\,' + param + '\,*,27';
	isIE = (document.all ? true : false);
	isDOM = (document.getElementById ? true : false);

		if (isIE) if(parent && parent.rightFrame) parent.rightFrame.rows=param1;
		else {
                    if(parent && parent.document && parent.document.getElementById('rightFrame')) parent.document.getElementById('rightFrame').rows=param1;
                }

}

//-----------------------------------------------------------------------------------------

function reloadSizeFrame() 
{
	isIE = (document.all ? true : false);
	isDOM = (document.getElementById ? true : false);

	if (isIE) if(parent && parent.parent && parent.parent.sizeFrame && parent.rightFrame && parent.rightFrame.rows) parent.parent.sizeFrame = parent.rightFrame.rows;
	else {
           if(parent && parent.document && parent.document.getElementById('rightFrame')) parent.parent.sizeFrame = parent.document.getElementById('rightFrame').rows; 
        }
	
}