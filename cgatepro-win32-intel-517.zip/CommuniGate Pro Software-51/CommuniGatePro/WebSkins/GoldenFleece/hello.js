sizeBox       = new Array();
messageBox    = new Array();
recentBox     = new Array();
unreadBox     = new Array();
List          = new Array();

var boxName     = '';
var mailboxName = 'INBOX';
var Message     = '';
var OrigMailbox = '';



var flagList = false;

var flagReply         = false;
var flagReplyAll      = false;
var flagForward       = false;
var flagEditEvent     = false;
var flagSaveEvent     = false;
var flagEditEventExit = false;
var flagEditTask      = false;
var flagSaveTask      = false;
var flagEditTaskExit  = false;
var flagEditNote      = false;
var flagEditContact   = false;
var flagEditGroup     = false;
var flagEditDraft     = false;
var flagSentBox       = false;

var flagNewGroup     = false;
var flagMailboxGroup = false;

var flagMailboxManagement = false;

var sizeFrame = '27,350,*,27';

var deleteFlag = 1;
var Flagget = 0;

var flagAlert = true;

