function checkLogout()
{ 
string = "";
if(parent && parent.mainFrame && parent.mainFrame.document ) string = new String(parent.mainFrame.document.location);
arrayOfStrings = string.split("/");
string = arrayOfStrings[arrayOfStrings.length-1];

if (string == 'mailboxeslayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame1.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame2.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.leftFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame0.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame3.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

if (string == 'composelayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.leftFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame0.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame1.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

if (string == 'eventlayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.leftFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame0.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame1.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

if (string == 'tasklayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.leftFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame0.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame1.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

if (string == 'notelayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.bottomFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

if (string == 'ruleslayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.leftFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

if (string == 'settingslayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.leftFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.rightFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

if (string == 'websitelayout.wssp')
{
	var frm = parent.mainFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	var frm = parent.mainFrame.leftFrame.document.getElementsByTagName('INPUT');
	for (var i = 0; i < frm.length; i++) 
	{

		if (frm[i].name == 'restoreSessionPage') 
		{
			parent.parent.document.location = "bye.wssp";
			return true;
		}
		
	}

	return;

}

}
