function menuMailboxBottom(param)
{
	if (param == 'SaveContact')
	{
		document.forms[0].elements[1].name='save';
		document.forms[0].submit();
		return true;
	}

	if (param == 'SaveAndNew')
	{
		document.forms[0].elements[1].name='SaveAndNew';
		document.forms[0].submit();
		return true;
	}
}