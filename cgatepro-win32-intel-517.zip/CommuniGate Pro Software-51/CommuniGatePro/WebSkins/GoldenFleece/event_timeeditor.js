/* ---------------------------------------------- --- */

function sendAddRecurrence()
{
	document.forms[0].elements[3].name='AddRecurrence';
	document.forms[0].elements[3].value='Add Recurrence'; 

	document.forms[0].action = 'compose.wssp?IsEvent=1&MessageText=12&';
	document.forms[0].submit();

	return false;
}
/* ---------------------------------------------- --- */

function sendDelRecurrence()
{

	document.forms[0].elements[3].name='DelRecurrence';
	document.forms[0].elements[3].value='Remove Recurrence'; 

	document.forms[0].action = 'compose.wssp?IsEvent=1&MessageText=12&';
	document.forms[0].submit();

	return false;
}
/* ---------------------------------------------- --- */

