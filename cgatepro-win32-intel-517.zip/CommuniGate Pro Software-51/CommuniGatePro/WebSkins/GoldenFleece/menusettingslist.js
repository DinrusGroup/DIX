function linkSettings(param)
{

	if (param == 1)
	{
		if(parent && parent.rightFrame) parent.rightFrame.document.location = 'listsettings.wssp?List=' + parent.parent.parent.NameList + '&'
	}
	if (param == 2)
	{
		if(parent && parent.rightFrame) parent.rightFrame.document.location = 'listarchivesettings.wssp?List=' + parent.parent.parent.NameList + '&'
	}
	if (param == 3)
	{
		if(parent && parent.rightFrame) parent.rightFrame.document.location = 'listsubscribers.wssp?List=' + parent.parent.parent.NameList + '&'
	}
	return;
}