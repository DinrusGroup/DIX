function menuMessage(param)
{
	if (param == 'NextUnRead')
	{
		parent.rightFrame1.document.location = 'mailbox.wssp?Mailbox=' + parent.parent.boxName + '&NextUnread=&';
		return true;
	}

	if (param == 'Reply')
	{
		parent.parent.flagReply    = true;
		parent.parent.flagReplyAll = false;
		parent.parent.flagForward  = false;

		parent.parent.mainFrame.document.location = 'composelayout.wssp';

		return true;
	}

	if (param == 'ReplyAll')
	{
		parent.parent.flagReply    = false;
		parent.parent.flagReplyAll = true;
		parent.parent.flagForward  = false;

		parent.parent.mainFrame.document.location = 'composelayout.wssp';

		return true;
	}

	if (param == 'Forward')
	{
		parent.parent.flagReply    = false;
		parent.parent.flagReplyAll = false;
		parent.parent.flagForward  = true;

		parent.parent.mainFrame.document.location = 'composelayout.wssp';

		return true;
	}

	if (param == 'Read')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='Read';
		parent.rightFrame1.document.forms[0].elements[1].value='Set';
		return true;
	}

	if (param == 'Flag')
	{
		parent.rightFrame2.document.forms[0].action = 'message.wssp?Mailbox=' + parent.parent.boxName + '&MSG=' + parent.parent.Message + '&Flag=&';
		parent.rightFrame2.document.forms[0].submit();

		parent.rightFrame1.document.action = 'mailbox.wssp?Mailbox=' + parent.parent.boxName + '&';
		parent.rightFrame1.document.forms[0].submit();

		document.location = 'menumessage.wssp';

		return true;
	}
	if (param == 'UnFlag')
	{
		parent.rightFrame2.document.forms[0].action = 'message.wssp?Mailbox=' + parent.parent.boxName + '&MSG=' + parent.parent.Message + '&UnFlag=&';
		parent.rightFrame2.document.forms[0].submit();

		parent.rightFrame1.document.action = 'mailbox.wssp?Mailbox=' + parent.parent.boxName + '&';
		parent.rightFrame1.document.forms[0].submit();

		document.location = 'menumessage.wssp';

		return true;
	}

	if (param == 'Delete')
	{
		parent.rightFrame1.document.location = 'mailbox.wssp?Mailbox=' + parent.parent.boxName + '&MSG=' + parent.parent.Message + '&Delete=&';

		checkReSize('550','550');
		parent.rightFrame2.document.location = 'blank0.html';
		parent.rightFrame3.document.location = 'blank0.html';

		return true;
	}
	if (param == 'UnRead')
	{
		parent.rightFrame1.document.forms[0].action = 'mailbox.wssp?Mailbox=' + parent.parent.boxName + '&MSG=' + parent.parent.Message + '&Unread=&';
		parent.rightFrame1.document.forms[0].submit();
		return true;
	}
	if (param == 'Purge')
	{
		parent.rightFrame1.document.forms[0].elements[1].name='Purge';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';
		return true;
	}
	

	if (param == 'Management')
	{
		str = 'mailboxsettings.wssp?Mailbox=';
		str += parent.parent.boxName;
		str += '&';

		checkReSize('450','300');

		parent.rightFrame2.document.location = str;

		return true;
	}
}

