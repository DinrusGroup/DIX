function funReset()
{
	document.forms[0].elements[1].name = 'Reset';
	document.forms[0].submit();
	return;
}

function funUpdate()
{
	document.forms[0].elements[1].name = 'Update';
	document.forms[0].submit();
	return;
}

function funUpdatePassword()
{
	document.forms[0].elements[1].name = 'ModifyPassword';
	document.forms[0].submit();
	return;
}
