function op()
{
	var fl="height=500,width=750, status=yes,toolbar=yes,menubar=yes,resizable=yes,location=yes";
	var nm= "_blank";

	window.open("bye.wssp", nm, fl, false);
}	

function goCallControll(){
	parent.mainFrame.location = 'callcontrollayout.wssp';
}
function goMail(){
	parent.mainFrame.location = 'maillayout.wssp';
}
function goBuddies(){
	parent.mainFrame.location = 'buddieslayout.wssp';
}

function goMailboxes()
{
	parent.mainFrame.location = 'mailboxeslayout.wssp';
}

function goCompose()
{
	parent.mainFrame.location = 'composelayout.wssp';
}

function goEvent()
{
	parent.mainFrame.location = 'eventlayout.wssp';
}

function goTask()
{
	parent.mainFrame.location = 'tasklayout.wssp';
}

function goNote()
{
	parent.mainFrame.location = 'notelayout.wssp';
}

function goRules()
{
	parent.mainFrame.location = 'ruleslayout.wssp';
}

function goSettings()
{
	parent.mainFrame.location = 'settingslayout.wssp';
}

function goWebSite()
{
	parent.mainFrame.location = 'websitelayout.wssp';
}
