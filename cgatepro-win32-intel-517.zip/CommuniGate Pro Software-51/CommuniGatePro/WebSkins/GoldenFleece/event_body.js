/* ---------------------------------------------- --- */
var selectPriority   = '';
var selectBusyStatus = '';

var fieldTo       = '';
var fieldSubject  = '';
var fieldCc       = '';
var fieldBcc      = '';
var fieldLocation = '';

var selectEventStartDate = '';
var textEventStartDate_D = '';
var textEventStartDate_M = '';
var textEventStartDate_Y = '';
var selectEventStartTime = '';
var checkboxallDayEvent  = '';
var selectEventDuration  = '';
var selectRecurrenceMode = '';

var fieldRecurrenceInterval    = '';
var fieldRecurrenceDayNum      = '';
var selectRecurrenceWeekNum    = '';
var selectRecurrenceMonthName  = '';
checkboxrecurrenceWeekDay = new Array();

function sendSave()
{
	selectPriority   = parent.headerFrame.document.forms[0].elements['Priority'].value;
	selectBusyStatus = parent.headerFrame.document.forms[0].elements['BusyStatus'].value;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	fieldCc       = parent.rightFrame0.document.forms[0].elements['Cc'].value;
	fieldBcc      = parent.rightFrame0.document.forms[0].elements['Bcc'].value;
	fieldLocation = parent.rightFrame0.document.forms[0].elements['Location'].value;
	
		
	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'BusyStatus';
	document.forms[0].elements[2].value =  selectBusyStatus;
		
	document.forms[0].elements[3].name  = 'To';
	document.forms[0].elements[3].value =  fieldTo;
		
	document.forms[0].elements[4].name  = 'Subject';
	document.forms[0].elements[4].value =  fieldSubject;
		
	document.forms[0].elements[5].name  = 'Cc';
	document.forms[0].elements[5].value =  fieldCc;
		
	document.forms[0].elements[6].name  = 'Bcc';
	document.forms[0].elements[6].value =  fieldBcc;
	
	document.forms[0].elements[7].name  = 'Location';
	document.forms[0].elements[7].value =  fieldLocation;
	

	document.forms[0].elements[22].name='Save';
	document.forms[0].elements[22].value='Save'; 
	
	parent.parent.parent.flagSaveEvent = true;
	
	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */
function sendShowFreeBusy(flagAllDayEvent)
{
	document.forms[0].elements[13].name='ShowFreeBusy';
	document.forms[0].elements[13].value='Show Availability'; 

	document.forms[0].action = 'compose.wssp?IsEvent=1&MessageText=12&';
	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */

/* ---------------------------------------------- --- */
function sendSMIME()
{
	selectPriority   = parent.headerFrame.document.forms[0].elements['Priority'].value;
	selectBusyStatus = parent.headerFrame.document.forms[0].elements['BusyStatus'].value;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	fieldCc       = parent.rightFrame0.document.forms[0].elements['Cc'].value;
	fieldBcc      = parent.rightFrame0.document.forms[0].elements['Bcc'].value;
	fieldLocation = parent.rightFrame0.document.forms[0].elements['Location'].value;
	
		
	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'BusyStatus';
	document.forms[0].elements[2].value =  selectBusyStatus;
		
	document.forms[0].elements[3].name  = 'To';
	document.forms[0].elements[3].value =  fieldTo;
		
	document.forms[0].elements[4].name  = 'Subject';
	document.forms[0].elements[4].value =  fieldSubject;
		
	document.forms[0].elements[5].name  = 'Cc';
	document.forms[0].elements[5].value =  fieldCc;
		
	document.forms[0].elements[6].name  = 'Bcc';
	document.forms[0].elements[6].value =  fieldBcc;
	
	document.forms[0].elements[7].name  = 'Location';
	document.forms[0].elements[7].value =  fieldLocation;
	

	document.forms[0].elements[22].name='SMIMEUnlock';
	document.forms[0].elements[22].value='Unlock Secure Mail'; 
	
	document.forms[0].submit();

	
	return;
}
/* ---------------------------------------------- --- */
function SpellCheck()
{
	selectPriority   = parent.headerFrame.document.forms[0].elements['Priority'].value;
	selectBusyStatus = parent.headerFrame.document.forms[0].elements['BusyStatus'].value;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	fieldCc       = parent.rightFrame0.document.forms[0].elements['Cc'].value;
	fieldBcc      = parent.rightFrame0.document.forms[0].elements['Bcc'].value;
	fieldLocation = parent.rightFrame0.document.forms[0].elements['Location'].value;
	
		
	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'BusyStatus';
	document.forms[0].elements[2].value =  selectBusyStatus;
		
	document.forms[0].elements[3].name  = 'To';
	document.forms[0].elements[3].value =  fieldTo;
		
	document.forms[0].elements[4].name  = 'Subject';
	document.forms[0].elements[4].value =  fieldSubject;
		
	document.forms[0].elements[5].name  = 'Cc';
	document.forms[0].elements[5].value =  fieldCc;
		
	document.forms[0].elements[6].name  = 'Bcc';
	document.forms[0].elements[6].value =  fieldBcc;
	
	document.forms[0].elements[7].name  = 'Location';
	document.forms[0].elements[7].value =  fieldLocation;
	

	document.forms[0].elements[23].name='SpellCheck';
	document.forms[0].elements[23].value='Check Spelling'; 
	
	document.forms[0].submit();

	
	return;
}
