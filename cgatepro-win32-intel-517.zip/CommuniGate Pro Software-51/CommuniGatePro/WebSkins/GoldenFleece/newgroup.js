/* ------------------------------------------------- */
var i = 0;

elemAddrBook = new Array();
elemIdAddrBook = new Array();

function addressBookAdd(param)
{
	switch (param) 
	{
		case 'BookToGroup':	
			document.forms[0].elements[1].name = 'BookToGroup';
			document.forms[0].elements[1].value = 'Add To Group';

			document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
			document.forms[0].submit();
			break;
		default:
			 break
	}

	return;

}

function addressBookDisplay()
{
	document.forms[0].elements[1].name = 'OpenBook';
	document.forms[0].elements[1].value = 'Display';

	document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
	document.forms[0].submit();
	
	return;
}

function addressBookDelete()
{
	document.forms[0].elements[1].name = 'DeleteBook';
	document.forms[0].elements[1].value = 'Delete';

	document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
	document.forms[0].submit();
	
	return;
}
function addressBookAddNew()
{
	document.forms[0].elements[1].name = 'AddBook';
	document.forms[0].elements[1].value = 'Add New';

	document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
	document.forms[0].submit();
	
	return;
}

function GroupDelete()
{
	document.forms[0].elements[1].name = 'DeleteGroup';
	document.forms[0].elements[1].value = 'Delete';

	document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
	document.forms[0].submit();
	
	return;
}
function AddGroupNew()
{
	document.forms[0].elements[1].name = 'AddGroup';
	document.forms[0].elements[1].value = 'Add New';

	document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
	document.forms[0].submit();
	
	return;
}

function SaveGroup()
{
	document.forms[0].elements[1].name = 'save';
	document.forms[0].elements[1].value = 'Save Group';

	parent.parent.flagMailboxGroup = true;

	document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
	document.forms[0].submit();
	
	return;
}

function SaveAndOpenNew()
{
	document.forms[0].elements[1].name = 'saveAndNew';
	document.forms[0].elements[1].value = 'Save And Open New';

	document.forms[0].action = 'contactgroup.wssp?addressBook=1&';
	document.forms[0].submit();
	
	return;
}

/* ---------------------------------------------- --- */

