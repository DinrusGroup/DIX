    function funDelete()
    {
        document.forms[0].elements[1].name = 'Remove';
        document.forms[0].submit();
        return;
    }

    function funUpload()
    {
        document.forms[0].elements[1].name = 'Create';
        document.forms[0].submit();
        return;
    }

    function funCreate()
    {
        document.forms[0].elements[1].name = 'CreateDir';
        document.forms[0].submit();
        return;
    }

    function funRename()
    {
        document.forms[0].elements[1].name = 'Rename';
        document.forms[0].submit();
        return;
    }

