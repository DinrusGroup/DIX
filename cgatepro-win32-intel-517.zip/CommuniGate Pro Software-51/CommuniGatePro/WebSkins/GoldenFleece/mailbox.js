//var idMSGTmp = "0";
var i = 4;
arrStatus = new Array();

function menuMailboxBottom(param)
{
	if (param == 'CopyTo')
	{
		document.forms[0].elements[1].name='Copy';
		document.forms[0].elements[1].value='Send';
		document.forms[0].submit();
		return true;
	}

	if (param == 'MoveTo')
	{
		document.forms[0].elements[1].name='Move';
		document.forms[0].elements[1].value='Send';
		document.forms[0].submit();
		return true;
	}

	if (param == 'RedirectTo')
	{
		document.forms[0].elements[1].name='Redirect';
		document.forms[0].elements[1].value='Send';
		document.forms[0].submit();
		return true;
	}
}

function downloadMenuBottom()
{

	  parent.rightFrame3.document.location = 'menumessage.wssp';

}

function checkSaveEventTask()
{
	if (parent.parent.flagSaveEvent)
	{
		document.location = 'calendar.wssp?Mailbox=' + parent.parent.mailboxName + '&';
		parent.parent.flagSaveEvent = false;
	}
	if (parent.parent.flagSaveTask)
	{
		document.location = 'tasks.wssp?Mailbox=' + parent.parent.mailboxName + '&';
		parent.parent.flagSaveTask = false;
	}
}

function reloadMailboxes0()
{
   try {
	parent.parent.hiddenFrame.document.location = 'mailboxes.wssp?MessageText=0&';
	return;
   }catch(e) {}
}

//***********

function dotRead(idMSG)
{
	if (idMSG == "start")
		if (parent.parent.idMSGTmp == "0") return;
		else
		{
//		alert(parent.parent.idMSGTmp);
			var dv = document.getElementById(parent.parent.idMSGTmp);

			if (dv && typeof(dv)=="object")
			{
				dv.innerHTML='<IMG SRC="red_dot.gif" border=0>';
	 		}
//		 	parent.parent.idMSGTmp = idMSG;
		 	return;
		}
	
	if (parent.parent.idMSGTmp == "0")
	{
		var dv = document.getElementById(idMSG);

		if (dv && typeof(dv)=="object")
		{
			dv.innerHTML='<IMG SRC="red_dot.gif" border=0>';
	 	}
	 	parent.parent.idMSGTmp = idMSG;
	 	return;
	}
	else
	{
		var dv = document.getElementById(parent.parent.idMSGTmp);

		if (dv && typeof(dv)=="object")
		{
			dv.innerHTML='<IMG SRC="1blank.gif" border=0>';
	 	}
		var dv = document.getElementById(idMSG);

		if (dv && typeof(dv)=="object")
		{
			dv.innerHTML='<IMG SRC="red_dot.gif" border=0>';
	 	}
	 	parent.parent.idMSGTmp = idMSG;
	 	return;
	}
	
	return;
}
