	function funCreate()
	{
		document.forms[0].elements[1].name = 'Create';
		document.forms[0].submit();
		return;
	}

	function funApply()
	{
		document.forms[0].elements[1].name = 'Update';
		document.forms[0].submit();
		return;
	}

	function funSelectAll()
	{
		document.forms[0].elements[1].name = 'SelectAll';
		document.forms[0].submit();
		return;
	}

	function funUnsubscribe()
	{
		document.forms[0].elements[1].name = 'Unsubscribe';
		document.forms[0].submit();
		return;
	}

	function funPostings()
	{
		document.forms[0].elements[1].name = 'Postings';
		document.forms[0].submit();
		return;
	}

	function funFailed()
	{
		document.forms[0].elements[1].name = 'Failed';
		document.forms[0].submit();
		return;
	}

	function funChangeMode()
	{
		document.forms[0].elements[1].name = 'ChangeMode';
		document.forms[0].submit();
		return;
	}
