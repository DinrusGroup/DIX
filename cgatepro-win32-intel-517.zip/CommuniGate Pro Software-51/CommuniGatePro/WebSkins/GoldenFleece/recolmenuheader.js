var kodeb, kodec;

function buttn(a, b)
{
	if (kodeb) kodeb.backgroundColor = kodec;
	kodeb = b = b.style;
	kodec = b.backgroundColor;
	switch (a)
	{
		case 0: b.backgroundColor='#E0E0E0'; break;
		case 2: b.borderStyle='outset'; break;
		case 3: b.borderStyle='inset'; break;
	}
}


function km0() {return false;}
function km1() {buttn(2,this);}
function km2() {buttn(3,this);}
function km3() {buttn(0,this);}
function km4() {buttn(1,this);buttn(2,this);}


function setCol()
{
	tg = document.getElementsByTagName("th");

	for (var k = 0; k < tg.length; k++)
	{
		if (tg[k].name == "recol")
		{
			tg[k].onmouseup = km1;
			tg[k].onmousedown = km2;
			tg[k].onmouseover = km3;
			tg[k].onmouseout = km4;
		}
		tg[k].onselectstart = km0;
	}
}

//----------------------------------------------------------

