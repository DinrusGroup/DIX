function menuMailbox(param)
{
	if (param == 'Display')
	{    try{
		parent.rightFrame1.document.forms[0].elements[1].name='Display';
		parent.rightFrame1.document.forms[0].elements[1].value='Send';

		parent.rightFrame1.document.forms[0].elements[2].name='Limit';
		parent.rightFrame1.document.forms[0].elements[2].value=document.forms[0].elements[0].value;

		parent.rightFrame1.document.forms[0].elements[3].name='Filter';
		parent.rightFrame1.document.forms[0].elements[3].value=document.forms[0].elements[1].value;

		parent.rightFrame1.document.forms[0].elements[4].name='Search';
		parent.rightFrame1.document.forms[0].elements[4].value=document.forms[0].elements[2].value;

		parent.rightFrame1.document.forms[0].submit();
	     }catch(e) {}	
	     return true;
	}
}