// doImageSubmit
// Workaround for buggy "input type=image" on IE 5.1 on Mac OS X
// Also used for submitting forms via selects
<!--
function doImageSubmit(task) {
  var field = document.forms[0].doImageSubmit;
  field.name = task;
  field.value = 1;
  document.forms[0].submit();
}
//-->
