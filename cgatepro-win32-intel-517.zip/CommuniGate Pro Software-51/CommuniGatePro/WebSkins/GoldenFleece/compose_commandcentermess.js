/* ---------------------------------------------- --- */

var addrbookflag = 0;
var attachmentflag = 0;
var forwardflag = 0;
var flagMouseDown = false;

/* ---------------------------------------------- --- */

function commandCenter(arg1)
{
	isIE = (document.all ? true : false);

	switch (arg1) 
	{
		case 'send':
			document.forms[0].elements[10].name='Send';
			document.forms[0].elements[10].value='Send'; 
			return true;
		case 'save':
			document.forms[0].elements[10].name='Save';
			document.forms[0].elements[10].value='Save in Drafts'; 
			return true;
		case 'SMIME':
			document.forms[0].elements[10].name='SMIMEUnlock';
			document.forms[0].elements[10].value='Unlock Secure Mail'; 
			return true;
		case 'SpellCheck':
			document.forms[0].elements[11].name='SpellCheck';
			document.forms[0].elements[11].value='Check Spelling'; 
			return true;
		case 'Help':
			contentsWindow = window.open("http://www.stalker.com/CommuniGatePro/","Help","toolbar=yes,location=yes,status=yes,menubar=yes,resizable=yes,directories=yes,scrollbars=yes,width=750,height=600");
			return true
		default:
			alert('Waiting for implementation');
	}
}


/* ---------------------------------------------- --- */

