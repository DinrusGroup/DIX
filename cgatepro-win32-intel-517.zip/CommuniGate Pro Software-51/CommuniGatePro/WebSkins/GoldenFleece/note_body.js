/* ---------------------------------------------- --- */
function sendSave()
{
	document.forms[0].elements[1].name='Save';
	document.forms[0].elements[1].value='Save'; 

	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */
