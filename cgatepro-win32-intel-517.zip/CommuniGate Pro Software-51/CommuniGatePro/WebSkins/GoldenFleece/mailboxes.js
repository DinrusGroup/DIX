/* ---------------------------------------------- Base functions --- */
function startMailboxes() {
	createBoxLayer=layer("createBox");
	createBoxLayer.setZIndex(10);
	createBoxLayer.hide();
	return true;
}

function showCreateBox() {
	document.forms[0].elements[3].value=parent.parent.mailboxNameCreate;
	createBoxLayer.show();
	return true;
}

function hideCreateBox() {
	createBoxLayer.hide();
	return true;
}

function reloadHeader(param) {
	try {
		if (param) {
			parent.headerFrame.document.location = 'headercalendar.wssp';
			parent.rightFrame0.document.location = 'menucalendar.wssp';
		} else {
			parent.headerFrame.document.location = 'mailbox.wssp?Mailbox=' + parent.parent.mailboxName + '&MessageText=001&';
			parent.rightFrame0.document.location = 'menumailbox.wssp';
		}
	} catch(e) {}
}

function goLIST (i) {
	try {
		parent.parent.parent.NameList = parent.parent.parent.List[i];
		parent.parent.parent.flagList = true;
		parent.parent.mainFrame.location = 'settingslistlayout.wssp';
	} catch(e) {}
	return;
}

function reloadrightFrame() {
	try {
		checkReSize('300','550');
		parent.rightFrame2.document.location = 'blank0.html';
		parent.rightFrame3.document.location = 'blank0.html';
	} catch(e) {}
}

function changeUnreadNew(Box, numUnReadMessages) {
	var numdiv = "div_0" + Box;
	var dv = document.getElementById(numdiv);
	if (numUnReadMessages > 0) {
		string ="(<b><font color=#FF0000>" + numUnReadMessages + "</font></b>)";
		if (dv && typeof(dv)=="object")	{
			dv.innerHTML = string;
		}
	} else {
		string ="&nbsp;";
		if (dv && typeof(dv)=="object") {
			dv.innerHTML=string;
		}
	}
	return;
}

function changesSizeBox(Box, sizeBox, nMessages) {
	var numdiv = "div_1" + Box;
	var dv = document.getElementById(numdiv);
	string = '' + sizeBox + '&nbsp;-&nbsp;' + nMessages;
	if (dv && typeof(dv) == "object") {
		dv.innerHTML=string;
	}
	return;
}

function defIdMSGTmp() {
	parent.parent.idMSGTmp = "0";
	return;
}
/* ---------------------------------------------- End of base functions --- */
