function menuCalendar(param)
{
    if (param == 'ViewAsFolder')
    {
        parent.rightFrame1.document.forms[0].action ='mailbox.wssp?Mailbox=' + parent.parent.parent.boxName + '&';
        parent.rightFrame1.document.forms[0].submit();

        parent.leftFrame.reloadHeader(0);
        return true;
    }

    if (param == 'ViewAsDay')
    {
        parent.rightFrame1.document.forms[0].action ='calendar.wssp?Mailbox=' + parent.parent.parent.boxName + '&CalendarView=Daily';
        parent.rightFrame1.document.forms[0].submit();

        return true;
    }
    if (param == 'ViewAsWeek')
    {
        parent.rightFrame1.document.forms[0].action ='calendar.wssp?Mailbox=' + parent.parent.parent.boxName + '&CalendarView=Weekly';
        parent.rightFrame1.document.forms[0].submit();

        return true;
    }
    if (param == 'ViewAsMonth')
    {
        parent.rightFrame1.document.forms[0].action ='calendar.wssp?Mailbox=' + parent.parent.parent.boxName + '&CalendarView=Monthly';
        parent.rightFrame1.document.forms[0].submit();

        return true;
    }

    if (param == 'Management')
    {
        str = 'mailboxsettings.wssp?Mailbox=';
        str += parent.parent.boxName;
        str += '&';

        checkReSize('550','300');

        parent.rightFrame2.document.location = str;
        parent.rightFrame3.document.location = 'blank0.html';

        return true;
    }
}

