var detectDir = "";

// setting varialbles
	// ie5+ supports all the methods in the tree, but not the hasFeature, so...
var ie5 = (document.all && document.getElementById)? true : false;
	// dom - all DOM2 compliant browsers (with MouseEvents 2 ;-)
var dom = (document.implementation && document.implementation.hasFeature("MouseEvents","2.0"))? true : false;

// tree variables
	// isTreeOpen
	// All tree branches are open if true, closed if false.
	// I've got plans to keep branch states in cookie, but it's not yet realized.
var isTreeOpen = false;

var treeBoxesINBOX = '';
var treeBoxesINDX  = '';

treeBoxes = new Array();
treeBoxesURL = new Array();
treeBoxesId = new Array();
treeBoxesSelectable = new Array();
treeBoxesList = new Array();
treeBoxesCalendar = new Array();
treeBoxesContacts = new Array();
treeBoxesNotes = new Array();
treeBoxesTasks = new Array();

treesizeBox = new Array();
treemessageBox = new Array();
treerecentBox = new Array();
treeunreadBox = new Array();

var indxBox = 0;
var numList = -1;
var numBox  = 0;

unreadInBox = new Array();

// look variables
	// By this value leafs will go deep.
var leafImgWidth = 16;
	// Default caption padding in the style
var leafCaptionDefPadding = 0;

//************************
//************************

var boxAtalon = "";

var point1 = 0;
var point2 = 0;
var point3 = 0;

var numNotChld = 0;
var numChld    = 0;

arrNotChld    = new Array();
arrChld       = new Array();
arrNotChldURL = new Array();
arrNotChldId = new Array();
arrChldURL    = new Array();
arrChldId = new Array();

function sortTree(colBoxes) {
	for (var i = 0; i < colBoxes - 1; i++) {
		boxAtalon = treeBoxes[i];
		var check1 = treeBoxes[i + 1].indexOf(boxAtalon); 
		if (check1 == 0) {
			point1 = i + 1;
			checkYes(colBoxes);
		}
		point1 = 0;
		numNotChld = 0;
		numChld = 0;
	}
	return;
}

function checkYes(colBoxes) {
	var boxAtalonSlash = boxAtalon + "/";
	for (j = point1; j < colBoxes - 1; j++)	{
		var check1 = treeBoxes[j].indexOf(boxAtalon); 
		if (check1 == -1) {
			if (numChld == 0) 
				return;
			else {
				sortBox();
				return;
			}
		}
		var check2 = treeBoxes[j].indexOf(boxAtalonSlash);
		if (check2 == 0) {
			arrChld[numChld] = treeBoxes[j];
			arrChldURL[numChld] = treeBoxesURL[j];
			arrChldId[numChld] = j;
			numChld++;
			continue;
		}
		if (check2 == -1) { // else
			if (numChld == 0) {
				arrNotChld[numNotChld] = treeBoxes[j];
				arrNotChldURL[numNotChld] = treeBoxesURL[j];
				arrNotChldId[numNotChld] = j;
				numNotChld++;
				continue;
			} else {
				break;
			}
		}
	}
	if (numChld == 0) 
		return;
	else {
		sortBox();
		return;
	}
	return;
}

function sortBox() {
	if (numChld == 0 || numNotChld == 0) 
		return;
	for (k = 0; k < numChld; k++) {
		treeBoxes[point1 + k] = arrChld[k];
		treeBoxesURL[point1 + k] = arrChldURL[k];
		treeBoxesId[point1 + k] = arrChldId[k];
	}
	for (k = 0; k < numNotChld; k++) {
		treeBoxes[point1 + numChld + k] = arrNotChld[k];
		treeBoxesURL[point1 + numChld + k] = arrNotChldURL[k];
		treeBoxesId[point1 + numChld + k] = arrNotChldId[k];
	}
	return;
}

function mboxList(mailboxName,treeBoxesINBOX,BoxmailboxPage,URLmailbox,checknotSelectable,checkCalendar,checkContact,checkNote,checkTask,checkList,sizeBox,nMessagesBox,nRecentBox,numUnreadBox) {
	treeBoxes[indxBox] = mailboxName;
	if (mailboxName == "INBOX") 
		treeBoxesINDX = mailboxName;
	if (treeBoxesINDX == "INBOX") 
		treeBoxesINBOX = mailboxName;
	treeBoxesURL[indxBox] = URLmailbox;
	if (treeBoxesINBOX == "INBOX") {
		try {
			if (parent.parent.mailboxName == "INBOX") {
				parent.rightFrame1.document.location = treeBoxesURL[indxBox];
				parent.headerFrame.document.location = treeBoxesURL[indxBox] + "MessageText=001&";
			} else {	// missed bracket???
				parent.rightFrame1.document.location = BoxmailboxPage + "?Mailbox=" + parent.parent.mailboxName + "&";
				parent.headerFrame.document.location = BoxmailboxPage + "?Mailbox=" + parent.parent.mailboxName + "&MessageText=001&";
			}
		} catch(e) {}
	}
	
	treeBoxesSelectable[indxBox] = checknotSelectable ? 0 : 1;
	treeBoxesCalendar[indxBox]   = checkCalendar ? 1 : 0;
	treeBoxesContacts[indxBox]   = checkContact ? 1 : 0;
	treeBoxesNotes[indxBox]      = checkNote ? 1 : 0;
	treeBoxesTasks[indxBox]      = checkTask ? 1 : 0;
	
	if (checkList) {
		treeBoxesList[indxBox] = 1;
		numList = numList + 1;
		parent.parent.List[numList] = mailboxName;
	} else
		treeBoxesList[indxBox]=0;

	treesizeBox[indxBox] = sizeBox;
	treemessageBox[indxBox] = nMessagesBox;
	treerecentBox[indxBox] = nRecentBox;
	treeunreadBox[indxBox] = numUnreadBox;
	return indxBox++;
}

function messageCode(messageText) {
	document.open();
	if (messageText != "1")
		document.write("<FONT COLOR=green>" + messageText + "</FONT>");
	document.close();
	return;
}

function layerCreate() {
	isIE = (document.all ? true : false);
	if (isIE) {
		document.open();
		document.write('<DIV id="createBox" style="position:absolute; visibility: hidden; top:3px;left:0px; width: 110%; height: 85px;"> ');
		document.close();
	} else {
		document.open();
		document.write('<DIV id="createBox" style="position:absolute; visibility: hidden; top:3px;left:0px; width: 100%; height: 85px;"> ');
		document.close();
	}
	return;
}
