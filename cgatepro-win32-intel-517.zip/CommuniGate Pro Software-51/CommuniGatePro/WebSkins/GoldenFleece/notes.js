function menuMailboxBottom(param)
{
	if (param == 'CopyTo')
	{
		document.forms[0].elements[1].name='Copy';
		document.forms[0].submit();
		return true;
	}

	if (param == 'MoveTo')
	{
		document.forms[0].elements[1].name='Move';
		document.forms[0].submit();
		return true;
	}

	if (param == 'RedirectTo')
	{
		document.forms[0].elements[1].name='Redirect';
		document.forms[0].submit();
		return true;
	}
}

function downloadMenuBottom()
{

	  parent.rightFrame3.document.location = 'menumessage.wssp';

}
