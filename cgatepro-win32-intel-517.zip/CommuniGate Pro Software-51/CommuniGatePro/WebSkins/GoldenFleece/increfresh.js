// A simple script to updates the contents of the Navigation frame
function refreshNavigation() {
var theSessionID = "";
theSessionID = String(arguments[0]);
parent.frames[0].document.location = "/Session/" + theSessionID + "/navigate.wssp";
}

// refreshMailboxes
// A simple script to updates the contents of the Mailboxes frame
function refreshMailboxes() {
//top.frames[0].document.location = 'Mailboxes.wssp'
}
