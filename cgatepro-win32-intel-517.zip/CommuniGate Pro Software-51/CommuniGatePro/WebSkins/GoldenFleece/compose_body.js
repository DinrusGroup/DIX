/* ---------------------------------------------- --- */
var selectPriority   = '';
var checkboxDSN      = '';
var checkboxMDN      = '';
var checkboxSaveSent = '';

var fieldTo       = '';
var fieldSubject  = '';
var fieldCc       = '';
var fieldBcc      = '';

function sendSend()
{
	selectPriority   = parent.headerFrame.document.forms[0].elements['Priority'].value;
	checkboxDSN      = parent.headerFrame.document.forms[0].elements['DSN'].checked;
	checkboxMDN      = parent.headerFrame.document.forms[0].elements['MDN'].checked;
	if (parent.parent.flagSentBox) checkboxSaveSent = parent.headerFrame.document.forms[0].elements['SaveSent'].checked;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	fieldCc       = parent.rightFrame0.document.forms[0].elements['Cc'].value;
	fieldBcc      = parent.rightFrame0.document.forms[0].elements['Bcc'].value;
	
	if (fieldTo == '' && fieldCc == '' && fieldBcc == '')
	{
		alert('No E-mail address is specified!');
		return;
	}
	
	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'DSN';
	if (checkboxDSN) document.forms[0].elements[2].value = 1;
	else document.forms[0].elements[2].value = 0;
		
	document.forms[0].elements[3].name  = 'MDN';
	if (checkboxMDN) document.forms[0].elements[3].value = 1;
	else document.forms[0].elements[3].value = 0;
		
	if (parent.parent.flagSentBox) 
	{
		document.forms[0].elements[4].name  = 'SaveSent';
		if (checkboxSaveSent) document.forms[0].elements[4].value = 1;
		else document.forms[0].elements[4].value = 0;
	}
		
	document.forms[0].elements[5].name  = 'To';
	document.forms[0].elements[5].value =  fieldTo;
		
	document.forms[0].elements[6].name  = 'Subject';
	document.forms[0].elements[6].value =  fieldSubject;
		
	document.forms[0].elements[7].name  = 'Cc';
	document.forms[0].elements[7].value =  fieldCc;
		
	document.forms[0].elements[8].name  = 'Bcc';
	document.forms[0].elements[8].value =  fieldBcc;
	
	commandCenter('send');

	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */

function saveDrafts()
{
	selectPriority   = parent.headerFrame.document.forms[0].elements['Priority'].value;
	checkboxDSN      = parent.headerFrame.document.forms[0].elements['DSN'].checked;
	checkboxMDN      = parent.headerFrame.document.forms[0].elements['MDN'].checked;
	if (parent.parent.flagSentBox) checkboxSaveSent = parent.headerFrame.document.forms[0].elements['SaveSent'].checked;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	fieldCc       = parent.rightFrame0.document.forms[0].elements['Cc'].value;
	fieldBcc      = parent.rightFrame0.document.forms[0].elements['Bcc'].value;
	

	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'DSN';
	if (checkboxDSN) document.forms[0].elements[2].value = 1;
	else document.forms[0].elements[2].value = 0;
		
	document.forms[0].elements[3].name  = 'MDN';
	if (checkboxMDN) document.forms[0].elements[3].value = 1;
	else document.forms[0].elements[3].value = 0;
		
	if (parent.parent.flagSentBox) 
	{
		document.forms[0].elements[4].name  = 'SaveSent';
		if (checkboxSaveSent) document.forms[0].elements[4].value = 1;
		else document.forms[0].elements[4].value = 0;
	}
		
	document.forms[0].elements[5].name  = 'To';
	document.forms[0].elements[5].value =  fieldTo;
		
	document.forms[0].elements[6].name  = 'Subject';
	document.forms[0].elements[6].value =  fieldSubject;
		
	document.forms[0].elements[7].name  = 'Cc';
	document.forms[0].elements[7].value =  fieldCc;
		
	document.forms[0].elements[8].name  = 'Bcc';
	document.forms[0].elements[8].value =  fieldBcc;

	commandCenter('save');

	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */
function sendSMIME()
{
	selectPriority   = parent.headerFrame.document.forms[0].elements['Priority'].value;
	checkboxDSN      = parent.headerFrame.document.forms[0].elements['DSN'].checked;
	checkboxMDN      = parent.headerFrame.document.forms[0].elements['MDN'].checked;
	if (parent.parent.flagSentBox) checkboxSaveSent = parent.headerFrame.document.forms[0].elements['SaveSent'].checked;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	fieldCc       = parent.rightFrame0.document.forms[0].elements['Cc'].value;
	fieldBcc      = parent.rightFrame0.document.forms[0].elements['Bcc'].value;
	
	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'DSN';
	if (checkboxDSN) document.forms[0].elements[2].value = 1;
	else document.forms[0].elements[2].value = 0;
		
	document.forms[0].elements[3].name  = 'MDN';
	if (checkboxMDN) document.forms[0].elements[3].value = 1;
	else document.forms[0].elements[3].value = 0;
		
	if (parent.parent.flagSentBox) 
	{
		document.forms[0].elements[4].name  = 'SaveSent';
		if (checkboxSaveSent) document.forms[0].elements[4].value = 1;
		else document.forms[0].elements[4].value = 0;
	}
		
	document.forms[0].elements[5].name  = 'To';
	document.forms[0].elements[5].value =  fieldTo;
		
	document.forms[0].elements[6].name  = 'Subject';
	document.forms[0].elements[6].value =  fieldSubject;
		
	document.forms[0].elements[7].name  = 'Cc';
	document.forms[0].elements[7].value =  fieldCc;
		
	document.forms[0].elements[8].name  = 'Bcc';
	document.forms[0].elements[8].value =  fieldBcc;
	
	commandCenter('SMIME');

	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */
function SpellCheck()
{
	selectPriority   = parent.headerFrame.document.forms[0].elements['Priority'].value;
	checkboxDSN      = parent.headerFrame.document.forms[0].elements['DSN'].checked;
	checkboxMDN      = parent.headerFrame.document.forms[0].elements['MDN'].checked;
	if (parent.parent.flagSentBox) checkboxSaveSent = parent.headerFrame.document.forms[0].elements['SaveSent'].checked;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	fieldCc       = parent.rightFrame0.document.forms[0].elements['Cc'].value;
	fieldBcc      = parent.rightFrame0.document.forms[0].elements['Bcc'].value;
	
	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'DSN';
	if (checkboxDSN) document.forms[0].elements[2].value = 1;
	else document.forms[0].elements[2].value = 0;
		
	document.forms[0].elements[3].name  = 'MDN';
	if (checkboxMDN) document.forms[0].elements[3].value = 1;
	else document.forms[0].elements[3].value = 0;
		
	if (parent.parent.flagSentBox) 
	{
		document.forms[0].elements[4].name  = 'SaveSent';
		if (checkboxSaveSent) document.forms[0].elements[4].value = 1;
		else document.forms[0].elements[4].value = 0;
	}
		
	document.forms[0].elements[5].name  = 'To';
	document.forms[0].elements[5].value =  fieldTo;
		
	document.forms[0].elements[6].name  = 'Subject';
	document.forms[0].elements[6].value =  fieldSubject;
		
	document.forms[0].elements[7].name  = 'Cc';
	document.forms[0].elements[7].value =  fieldCc;
		
	document.forms[0].elements[8].name  = 'Bcc';
	document.forms[0].elements[8].value =  fieldBcc;
	
	commandCenter('SpellCheck');

	document.forms[0].submit();
	
	return;
}
