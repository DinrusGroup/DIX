/* ---------------------------------------------- --- */
var selectPriority        = '';
var selectpercentComplete = '';

var fieldTo       = '';
var fieldSubject  = '';


function sendSave()
{
	selectPriority        = parent.headerFrame.document.forms[0].elements['Priority'].value;
	selectpercentComplete = parent.headerFrame.document.forms[0].elements['percentComplete'].value;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;


//	if (fieldTo == '')
//	{
//		alert('No E-mail address is specified!');
//		return;
//	}


	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'percentComplete';
	document.forms[0].elements[2].value =  selectpercentComplete;

	document.forms[0].elements[3].name  = 'To';
	document.forms[0].elements[3].value =  fieldTo;
		
	document.forms[0].elements[4].name  = 'Subject';
	document.forms[0].elements[4].value =  fieldSubject;
		
	document.forms[0].elements[9].name='Save';
	document.forms[0].elements[9].value='Save'; 

	parent.parent.parent.flagSaveTask = true;
	
	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */
function sendSMIME()
{
	selectPriority        = parent.headerFrame.document.forms[0].elements['Priority'].value;
	selectpercentComplete = parent.headerFrame.document.forms[0].elements['percentComplete'].value;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	

	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'percentComplete';
	document.forms[0].elements[2].value =  selectpercentComplete;

	document.forms[0].elements[3].name  = 'To';
	document.forms[0].elements[3].value =  fieldTo;
		
	document.forms[0].elements[4].name  = 'Subject';
	document.forms[0].elements[4].value =  fieldSubject;
		
	document.forms[0].elements[9].name='SMIMEUnlock';
	document.forms[0].elements[9].value='Unlock Secure Mail'; 

	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */
function SpellCheck()
{
	selectPriority        = parent.headerFrame.document.forms[0].elements['Priority'].value;
	selectpercentComplete = parent.headerFrame.document.forms[0].elements['percentComplete'].value;

	fieldTo       = parent.rightFrame0.document.forms[0].elements['To'].value;
	fieldSubject  = parent.rightFrame0.document.forms[0].elements['Subject'].value;
	

	document.forms[0].elements[1].name  = 'Priority';
	document.forms[0].elements[1].value =  selectPriority;
		
	document.forms[0].elements[2].name  = 'percentComplete';
	document.forms[0].elements[2].value =  selectpercentComplete;

	document.forms[0].elements[3].name  = 'To';
	document.forms[0].elements[3].value =  fieldTo;
		
	document.forms[0].elements[4].name  = 'Subject';
	document.forms[0].elements[4].value =  fieldSubject;
		
	document.forms[0].elements[10].name='SpellCheck';
	document.forms[0].elements[10].value='Check Spelling'; 

	document.forms[0].submit();
	
	return;
}
/* ---------------------------------------------- --- */
