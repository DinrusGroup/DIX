function menuTop(param)
{
	if (param == 'EditContact')
	{
		parent.parent.flagReply     = false;
		parent.parent.flagReplyAll  = false;
		parent.parent.flagForward   = false;
		parent.parent.flagEditContact = true;

		str  = 'contact.wssp?OrigMessage=';
		str += parent.parent.Message + '&OrigMailbox=';
		str += parent.parent.OrigMailbox + '&';

		parent.rightFrame1.document.location = str;

		parent.rightFrame1.ReSize('600');

		return true;
	}

	if (param == 'EditGroup')
	{
		parent.parent.flagReply     = false;
		parent.parent.flagReplyAll  = false;
		parent.parent.flagForward   = false;
		parent.parent.flagEditGroup = true;

		parent.parent.mainFrame.document.location = 'newgrouplayout.wssp';

		return true;
	}

	if (param == 'EditEvent')
	{
		parent.parent.flagReply     = false;
		parent.parent.flagReplyAll  = false;
		parent.parent.flagForward   = false;
		parent.parent.flagEditEvent = true;

		parent.parent.mainFrame.document.location = 'eventlayout.wssp';

		return true;
	}

	if (param == 'EditDraft')
	{
		parent.parent.flagReply     = false;
		parent.parent.flagReplyAll  = false;
		parent.parent.flagForward   = false;
		parent.parent.flagEditDraft = true;

		parent.parent.mainFrame.document.location = 'composelayout.wssp';

		return true;
	}

	if (param == 'RemoveEvent')
	{
		parent.rightFrame1.document.location = 'mailbox.wssp?Mailbox=' + parent.parent.OrigMailbox + '&MSG=' + parent.parent.Message + '&Delete=&';

		checkReSize('550','550');
		parent.rightFrame2.document.location = 'blank0.html';
		parent.rightFrame3.document.location = 'blank0.html';

		return true;
	}

	if (param == 'EditTask')
	{
		parent.parent.flagEditTask = true;

		parent.parent.mainFrame.document.location = 'tasklayout.wssp';

		return true;
	}

	if (param == 'CancelTask')
	{
		parent.rightFrame1.document.location = 'mailbox.wssp?Mailbox=' + parent.parent.OrigMailbox + '&MSG=' + parent.parent.Message + '&Delete=&';

		checkReSize('550','550');
		parent.rightFrame2.document.location = 'blank0.html';
		parent.rightFrame3.document.location = 'blank0.html';

		return true;
	}

	if (param == 'EditNote')
	{
		parent.parent.flagEditNote = true;

		parent.parent.mainFrame.document.location = 'notelayout.wssp';

		return true;
	}

	if (param == 'Close')
	{
		checkReSize('550','550');
		parent.rightFrame2.document.location = 'blank0.html';
		parent.rightFrame3.document.location = 'blank0.html';

		return true;
	}
}

function menuMailboxBottom(param)
{
	if (param == 'CopyTo')
	{
		document.forms[0].elements[2].name='Copy';
		document.forms[0].elements[2].value='Send';
		document.forms[0].submit();
		return true;
	}

	if (param == 'MoveTo')
	{
		document.forms[0].elements[2].name='Move';
		document.forms[0].elements[2].value='Send';
		document.forms[0].submit();
		return true;
	}

	if (param == 'RedirectTo')
	{
		document.forms[0].elements[2].name='Redirect';
		document.forms[0].elements[2].value='Send';
		document.forms[0].submit();
		return true;
	}
}

function TakeAddress()
{
	document.forms[0].elements[1].name = 'TakeAddress';
	document.forms[0].submit();
	return;
}

function StoreFiles()
{
	document.forms[0].elements[1].name = 'StoreFiles';
	document.forms[0].submit();
	return;
}

function TakeVCard()
{
	document.forms[0].elements[1].name = 'TakeVCard';
	document.forms[0].submit();
	return;
}

function TakeCertificate()
{
	document.forms[0].elements[1].name = 'TakeCertificate';
	document.forms[0].submit();
	return;
}

