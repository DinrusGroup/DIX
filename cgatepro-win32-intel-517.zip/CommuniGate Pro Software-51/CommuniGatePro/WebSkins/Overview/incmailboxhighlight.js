// This highlights the Mailbox of the same name in the Mailboxes frame
function highlightMailbox() {
try{
var theMailboxname = "";
theMailboxname = String(arguments[0]);
parent.frames[0].document.getElementById(theMailboxname).className='GeneralTextHighlighted';
}catch(e) {}
}
