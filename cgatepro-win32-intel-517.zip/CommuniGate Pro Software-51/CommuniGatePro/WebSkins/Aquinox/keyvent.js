function KEYVENT(){
	this.isDOM=(document.getElementById)?1:0;
	this.isNS6=(this.dom&&navigator.appName=="Netscape");
	this.isOP=(window.opera? 1:0);
	this.isIE=(document.all);

	this.RKEYS_SHIFT_KEYCODE = 16;
	this.RKEYS_CTRL_KEYCODE = 17;
	this.RKEYS_ALT_KEYCODE = 18;
	this.RKEYS_SHIFT = "shift";
	this.RKEYS_CTRL = "ctrl";
	this.RKEYS_ALT = "alt";
	this.count=0;

	this.id = "keyvent"+this.count++;
	eval(this.id + "=this");
	this.keys = new Array();
	this.shift=0;
	this.ctrl=0;
	this.alt=0;
};

KEYVENT.prototype.addKey = function(a,m,key){
	if(this.isIE||this.isDOM) this.keys[key.charCodeAt(0)] = [a,m];
	else this.keys[-1] = [a,m];
};

KEYVENT.prototype.addEvent = function(el, evname) {
        var meObject = this;
        var elcall = el;
	if (this.isIE) {
	        if(el.contentWindow && el.contentWindow.document)  elcall = el.contentWindow.document;
	        elcall.attachEvent("on" + evname, function(evt) { meObject.eventFunction(evt); } );
	} else {
	        if(el.contentDocument)  elcall = el.contentDocument;
		elcall.addEventListener(evname, function(evt) { meObject.eventFunction(evt); }, true);
	}
};

KEYVENT.prototype.addEvents = function(el, evs) {
	for (var i in evs) {
		this.addEvent(el, evs[i]);
	}
};
KEYVENT.prototype.eventFunction = function(evt){
        try{
        var meObject = this;
	if(this.isIE||this.isOP) evt=event;
	var k = (this.isIE||this.isOP||this.isNS6)? evt.keyCode:evt.which;
	meObject.checkModKeys(evt,k);
	if(this.keys[k]==null) return false;
	var m = this.keys[k][1];
	if((this.shift && (m.indexOf(this.RKEYS_SHIFT) != -1) || !this.shift && (m.indexOf(this.RKEYS_SHIFT) == -1)) && (this.ctrl && (m.indexOf(this.RKEYS_CTRL) != -1) || !this.ctrl && (m.indexOf(this.RKEYS_CTRL) == -1)) && (this.alt && (m.indexOf("alt") != -1) || !this.alt && (m.indexOf("alt") == -1))){
		var a = this.keys[k][0];
		a = eval(a); 
		if(typeof a == "function"){
			 a();
		}
	}
	}catch(e) {}
};

KEYVENT.prototype.checkModKeys = function(e,k){
	if(this.isDOM){ 
		this.shift = e.shiftKey;
		this.ctrl = e.ctrlKey;
		this.alt = e.altKey;
	}
	else{
		this.shift = (k==this.RKEYS_SHIFT_KEYCODE) ? 1:0;
		this.ctrl = (k==this.RKEYS_CTRL_KEYCODE) ? 1:0;
		this.alt = (k==this.RKEYS_ALT_KEYCODE) ? 1:0;
	}
};
/**/
function shift_ctrl_c(){
}
function shift_ctrl_p(){
    top.MainView.location.href = "compose.wssp";
}
function shift_ctrl_f(){
    top.MainView.location.href = "Mailbox.wssp?Mailbox=INBOX";
}
function shift_ctrl_s(){
   SessionDirectory=window.open('SessionDirectory.wssp','SessionDirectory','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=300,left=20,top=20'); return false;
}
function shift_ctrl_h(){
   var Win = window.open("helpmail.wssp","_blank");
   if(Win) Win.focus();
}


var keyEvent = new KEYVENT();
keyEvent.addKey(function(){shift_ctrl_c();},"shift+ctrl","C");
keyEvent.addKey(function(){shift_ctrl_p();},"shift+ctrl","P");
keyEvent.addKey(function(){shift_ctrl_f();},"shift+ctrl","F");
keyEvent.addKey(function(){shift_ctrl_s();},"shift+ctrl","S");
keyEvent.addKey(function(){shift_ctrl_h();},"shift+ctrl","H");
keyEvent.addEvents(document,["keydown"]);
